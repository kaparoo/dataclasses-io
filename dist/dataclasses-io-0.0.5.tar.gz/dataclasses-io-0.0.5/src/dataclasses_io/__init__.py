# -*- coding: utf-8 -*-

from dataclasses_io.api import dataclass_io


__all__ = ["dataclass_io"]
